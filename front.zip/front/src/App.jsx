import { createBrowserRouter, RouterProvider } from 'react-router-dom';
import PaginaCadastro from './pages/paginaCadastro'
import PaginaLogin from './pages/paginaLogin'

function App() {
  const router = createBrowserRouter([
    {
      path: '/',
      element: <PaginaCadastro />
    },
    {
      path: '/login',
      element: <PaginaLogin />
    },
  ]);

  return <RouterProvider router={router} />;
}

export default App
