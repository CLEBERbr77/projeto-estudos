import { useCallback, useEffect, useMemo, useState } from 'react';
import api from '../services/api';
import { AuthContext } from './AuthContext';

const TOKEN_KEY = 'token';

function lerToken() {
  try {
    return localStorage.getItem(TOKEN_KEY);
  } catch {
    return null;
  }
}

export default function AuthProvider({ children }) {
  const [token, setToken] = useState(lerToken);
  const [user, setUser] = useState(null);

  const entrar = useCallback((novoToken, usuario = null) => {
    try {
      localStorage.setItem(TOKEN_KEY, novoToken);
    } catch {
      /* armazenamento indisponível: a sessão vale só até recarregar */
    }
    setToken(novoToken);
    setUser(usuario);
  }, []);

  const sair = useCallback(() => {
    try {
      localStorage.removeItem(TOKEN_KEY);
    } catch {
      /* nada a fazer */
    }
    setToken(null);
    setUser(null);
  }, []);

  // com token e sem dados do usuário, busca o perfil (ajuste a rota ao seu backend)
  useEffect(() => {
    if (!token || user) return;

    let cancelado = false;
    api
      .get('/me')
      .then(({ data }) => {
        if (!cancelado) setUser(data);
      })
      .catch((err) => {
        if (err.response?.status === 401) sair();
      });

    return () => {
      cancelado = true;
    };
  }, [token, user, sair]);

  const value = useMemo(
    () => ({ token, user, autenticado: Boolean(token), entrar, sair }),
    [token, user, entrar, sair]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}